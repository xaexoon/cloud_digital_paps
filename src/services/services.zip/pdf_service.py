import os
import math
from dataclasses import dataclass
from io import BytesIO
from typing import Optional, Dict

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader, PdfWriter

# ============================================
# 좌표 설정 (이미지 좌표 기준)
# ============================================
COORDINATES = {
    # 상단 정보
    'name': (540, 16),
    'school': (660, 16),
    'age': (540, 34),
    'class_info': (660, 34),
    'gender': (540, 52),

    # 키, 몸무게, 비만도
    'height': (102, 465),
    'weight': (220, 465),
    'bmi': (334, 465),

    # 등급 박스
    'grade_50m': (540, 173),
    'grade_shuttle': (692, 173),
    'grade_rolling_up': (540, 245),
    'grade_flexibility': (692, 245),
    'grade_long_jump': (540, 317),
    'grade_bmi': (682, 317),
    'grade_grip_left': (540, 389),
    'grade_grip_right': (692, 389),
    'grade_total': (628, 453),

    # 레이더 차트
    'radar_center': (209, 276),
    'radar_radius': 65,

    # 그래프 바 y 좌표
    'bar_50m': 622,
    'bar_shuttle': 687,
    'bar_rolling_up': 752,
    'bar_flexibility': 817,
    'bar_long_jump': 882,
    'bar_grip_right': 947,
    'bar_grip_left': 1012,

    # 그래프 바 설정
    'bar_base_x': 163,
    'bar_width': 549,
    'bar_height': 18,
}

# 오프셋 설정
OFFSET = {
    'x': 30,
    'y': 30,
}

# 색상 설정
COLORS = {
    'text_dark': '#333333',
    'grade_blue': '#5D95F3',
    'grade_white': '#FFFFFF',
    'bar_blue': '#2A487B',
    'radar_fill': (0.23, 0.35, 0.55, 0.5),
    'radar_stroke': '#2B5797',
}

# 1등급 커트라인 (기본값 - 여학생 17세 기준)
DEFAULT_CUTOFF = {
    'run_50m': 8.60,
    'shuttle_run': 55,
    'rolling_up': 40,
    'flexibility': 17.0,
    'long_jump': 186.1,
    'grip_right': 37.5,
    'grip_left': 37.5,
}


# ============================================
# 데이터 모델
# ============================================
@dataclass
class StudentData:
    """학생 데이터 모델"""
    name: str
    age: int
    gender: str
    school: str
    class_info: str
    height: float
    weight: float
    bmi: float

    # 측정 결과
    run_50m: float
    shuttle_run: int
    rolling_up: int
    flexibility: float
    long_jump: float
    grip_right: float
    grip_left: float

    # 등급 (1~5)
    grade_50m: int = 1
    grade_shuttle: int = 1
    grade_rolling_up: int = 1
    grade_flexibility: int = 1
    grade_long_jump: int = 1
    grade_grip_right: int = 1
    grade_grip_left: int = 1
    grade_bmi: object = 1  # int 또는 str
    grade_total: int = 1


# ============================================
# PDF 생성기 클래스
# ============================================
class PapsPdfGenerator:
    """PAPS PDF 생성기"""

    def __init__(self, template_path: str, font_path: str = None, cutoff: dict = None):
        self.template_path = template_path
        self.cutoff = cutoff or DEFAULT_CUTOFF
        self.width, self.height = A4  # 595.27 x 841.89

        # 이미지 좌표 → PDF 좌표 변환용
        self.img_width = 794
        self.img_height = 1123

        # 폰트 등록
        self._register_fonts(font_path)

    def _register_fonts(self, font_path: str = None):
        """폰트 등록"""
        try:
            if font_path:
                pdfmetrics.registerFont(TTFont('SUIT-Regular', f'{font_path}/SUIT-Regular.ttf'))
                pdfmetrics.registerFont(TTFont('SUIT-Bold', f'{font_path}/SUIT-Bold.ttf'))
            self.font_regular = 'SUIT-Bold'
            self.font_bold = 'SUIT-Bold'
        except:
            self.font_regular = 'Helvetica'
            self.font_bold = 'Helvetica-Bold'

    def _img_to_pdf(self, img_x: float, img_y: float) -> tuple:
        """이미지 좌표를 PDF 좌표로 변환"""
        adjusted_x = img_x + OFFSET['x']
        adjusted_y = img_y + OFFSET['y']

        pdf_x = adjusted_x * self.width / self.img_width
        pdf_y = self.height - (adjusted_y * self.height / self.img_height)
        return pdf_x, pdf_y

    @staticmethod
    def _get_bmi_label(grade) -> str:
        """BMI 등급을 문자열로 변환"""
        if isinstance(grade, str):
            return grade
        bmi_labels = {
            1: "정상",
            2: "과체중",
            3: "경도비만",
            4: "중등도비만",
            5: "고도비만",
        }
        return bmi_labels.get(grade, str(grade))

    def generate(self, data: StudentData, output_path: str) -> str:
        """PDF 생성"""
        # 오버레이 PDF 생성
        overlay_buffer = BytesIO()
        c = canvas.Canvas(overlay_buffer, pagesize=A4)

        # 각 요소 오버레이
        self._draw_text_values(c, data)
        self._draw_bar_charts(c, data)
        self._draw_radar_chart(c, data)

        c.save()

        # 템플릿과 오버레이 병합
        overlay_buffer.seek(0)
        template_pdf = PdfReader(self.template_path)
        overlay_pdf = PdfReader(overlay_buffer)

        writer = PdfWriter()
        template_page = template_pdf.pages[0]
        overlay_page = overlay_pdf.pages[0]

        # 템플릿을 A4 크기로 스케일링
        template_page.scale_to(self.width, self.height)

        template_page.merge_page(overlay_page)
        writer.add_page(template_page)

        with open(output_path, 'wb') as f:
            writer.write(f)

        return output_path

    def _draw_text_values(self, c: canvas.Canvas, data: StudentData):
        """텍스트 값 그리기"""
        # 상단 정보
        c.setFillColor(colors.HexColor(COLORS['text_dark']))
        c.setFont(self.font_regular, 8)

        x, y = self._img_to_pdf(*COORDINATES['name'])
        c.drawString(x, y, data.name)

        x, y = self._img_to_pdf(*COORDINATES['school'])
        c.drawString(x, y, data.school)

        x, y = self._img_to_pdf(*COORDINATES['age'])
        c.drawString(x, y, f"{data.age}세")

        x, y = self._img_to_pdf(*COORDINATES['class_info'])
        c.drawString(x, y, data.class_info)

        x, y = self._img_to_pdf(*COORDINATES['gender'])
        c.drawString(x, y, data.gender)

        # 키, 몸무게, 비만도
        c.setFillColor(colors.HexColor(COLORS['grade_blue']))
        c.setFont(self.font_bold, 10)

        x, y = self._img_to_pdf(*COORDINATES['height'])
        c.drawCentredString(x, y, f"{data.height}cm")

        x, y = self._img_to_pdf(*COORDINATES['weight'])
        c.drawCentredString(x, y, f"{data.weight}kg")

        x, y = self._img_to_pdf(*COORDINATES['bmi'])
        c.drawCentredString(x, y, f"{data.bmi:.2f}")

        # 등급 표시 (BMI 제외)
        c.setFillColor(colors.HexColor(COLORS['grade_blue']))
        c.setFont(self.font_bold, 11)

        grade_items = [
            ('grade_50m', data.grade_50m),
            ('grade_shuttle', data.grade_shuttle),
            ('grade_rolling_up', data.grade_rolling_up),
            ('grade_flexibility', data.grade_flexibility),
            ('grade_long_jump', data.grade_long_jump),
            ('grade_grip_left', data.grade_grip_left),
            ('grade_grip_right', data.grade_grip_right),
        ]

        for key, grade in grade_items:
            x, y = self._img_to_pdf(*COORDINATES[key])
            c.drawCentredString(x, y, f"{grade}등급")

        # BMI 등급 (문자열로 표시, "등급" 안 붙임)
        x, y = self._img_to_pdf(*COORDINATES['grade_bmi'])
        bmi_label = self._get_bmi_label(data.grade_bmi)
        c.drawCentredString(x, y, bmi_label)

        # 종합등급 (흰색)
        c.setFillColor(colors.white)
        c.setFont(self.font_bold, 14)
        x, y = self._img_to_pdf(*COORDINATES['grade_total'])
        c.drawCentredString(x, y, f"{data.grade_total}등급")

    def _draw_bar_charts(self, c: canvas.Canvas, data: StudentData):
        """바 차트 그리기"""

        # (bar_y, value, max_value, reverse, unit)
        # max_value = 1등급 커트라인
        bar_data = [
            (COORDINATES['bar_50m'], data.run_50m, 8.60, True, "초"),
            (COORDINATES['bar_shuttle'], data.shuttle_run, 55, False, "회"),
            (COORDINATES['bar_rolling_up'], data.rolling_up, 40, False, "회"),
            (COORDINATES['bar_flexibility'], data.flexibility, 17.0, False, "cm"),
            (COORDINATES['bar_long_jump'], data.long_jump, 186.1, False, "cm"),
            (COORDINATES['bar_grip_right'], data.grip_right, 37.5, False, "kg"),
            (COORDINATES['bar_grip_left'], data.grip_left, 37.5, False, "kg"),
        ]

        base_x = COORDINATES['bar_base_x']
        bar_width = COORDINATES['bar_width']
        bar_height = COORDINATES['bar_height']

        for bar_y, value, max_val, reverse, unit in bar_data:
            pdf_x, pdf_y = self._img_to_pdf(base_x, bar_y)
            pdf_bar_width = bar_width * self.width / self.img_width
            pdf_bar_height = bar_height * self.height / self.img_height

            # 미측정(0)이면 바 그리지 않음
            if value == 0:
                c.setFillColor(colors.HexColor(COLORS['text_dark']))
                c.setFont(self.font_regular, 8)
                c.drawString(pdf_x + 5, pdf_y - 3, f"0{unit}")
                continue

            # 값 기반 비율 계산 (1등급 커트라인 = 80% 위치)
            if reverse:
                ratio = (12 - value) / (12 - max_val) * 0.80
            else:
                ratio = (value / max_val) * 0.80

            # 최대 제한 없음 (1등급 초과 시 회색 바 넘어감)
            ratio = max(0.05, ratio)

            fill_width = pdf_bar_width * ratio

            # 둥근 모서리 바 그리기
            c.setFillColor(colors.HexColor(COLORS['bar_blue']))
            radius = pdf_bar_height / 4
            c.roundRect(pdf_x, pdf_y - pdf_bar_height / 2, fill_width, pdf_bar_height, radius, fill=1, stroke=0)

            # 바 끝에 값 표시
            c.setFillColor(colors.HexColor(COLORS['text_dark']))
            c.setFont(self.font_regular, 8)
            c.drawString(pdf_x + fill_width + 5, pdf_y - 3, f"{value}{unit}")

    def _draw_radar_chart(self, c: canvas.Canvas, data: StudentData):
        """레이더 차트 그리기"""
        cx, cy = self._img_to_pdf(*COORDINATES['radar_center'])
        radius = COORDINATES['radar_radius']

        # 등급을 비율로 변환 (1등급=1.0, 5등급=0.2)
        def grade_to_ratio(grade):
            ratios = {
                1: 1.0,
                2: 0.83,
                3: 0.66,
                4: 0.47,
                5: 0.30,
            }
            return ratios.get(grade, 0.5)

        # BMI 등급을 숫자로 변환 (레이더 차트용)
        bmi_grade = data.grade_bmi
        if isinstance(bmi_grade, str):
            bmi_grade_map = {"정상": 1, "과체중": 2, "경도비만": 3, "중등도비만": 4, "고도비만": 5}
            bmi_grade = bmi_grade_map.get(bmi_grade, 5)

        values = [
            grade_to_ratio(data.grade_50m),
            grade_to_ratio(data.grade_shuttle),
            grade_to_ratio(data.grade_rolling_up),
            grade_to_ratio(data.grade_flexibility),
            grade_to_ratio(data.grade_long_jump),
            grade_to_ratio(bmi_grade),
            grade_to_ratio(data.grade_grip_left),
            grade_to_ratio(data.grade_grip_right),
        ]

        n = 8
        angles = [math.pi / 2 - (2 * math.pi * i / n) for i in range(n)]

        # 다각형 그리기
        rgba = COLORS['radar_fill']
        c.setFillColor(colors.Color(rgba[0], rgba[1], rgba[2], alpha=rgba[3]))
        c.setStrokeColor(colors.HexColor(COLORS['radar_stroke']))
        c.setLineWidth(1.5)

        path = c.beginPath()
        for i, (angle, value) in enumerate(zip(angles, values)):
            r = radius * max(0.2, value)
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            if i == 0:
                path.moveTo(x, y)
            else:
                path.lineTo(x, y)
        path.close()
        c.drawPath(path, fill=1, stroke=1)