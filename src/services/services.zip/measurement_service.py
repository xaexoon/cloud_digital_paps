"""측정 데이터 관련 비즈니스 로직"""

from typing import Dict, Optional, Tuple
from src.utils.grade_utils import get_grade, calculate_total_grade, calculate_bmi


class MeasurementService:
    """측정 데이터 처리 서비스"""

    @staticmethod
    def extract_grip_data(measurement: Dict) -> Tuple[float, float]:
        """악력 데이터 추출 (좌, 우)"""
        grip_data = measurement.get("gripStrength", {})
        if isinstance(grip_data, dict):
            grip_right = grip_data.get("rightGrip", 0) or 0
            grip_left = grip_data.get("leftGrip", 0) or 0
        else:
            grip_right = 0
            grip_left = 0
        return grip_left, grip_right

    @staticmethod
    def extract_grip_grades(measurement: Dict) -> Tuple[Optional[int], Optional[int]]:
        """악력 등급 추출 (좌, 우)"""
        grip_grade = measurement.get("grade_gripStrength", {})
        if isinstance(grip_grade, dict):
            grade_grip_right = grip_grade.get("rightGrip")
            grade_grip_left = grip_grade.get("leftGrip")
        else:
            grade_grip_right = None
            grade_grip_left = None
        return grade_grip_left, grade_grip_right

    @staticmethod
    def calculate_all_grades(measurement: Dict, bmi: float, grip_left: float, grip_right: float,
                              grade_grip_left: Optional[int], grade_grip_right: Optional[int]) -> int:
        """모든 종목의 종합 등급 계산"""
        all_grades = [
            get_grade(measurement.get("50mRun"), measurement.get("grade_50mRun")),
            get_grade(measurement.get("shuttleRun"), measurement.get("grade_shuttleRun")),
            get_grade(measurement.get("rollingUp"), measurement.get("grade_rollingUp")),
            get_grade(measurement.get("sitAndReach"), measurement.get("grade_sitAndReach")),
            get_grade(measurement.get("longJump"), measurement.get("grade_longJump")),
            get_grade(grip_right, grade_grip_right),
            get_grade(grip_left, grade_grip_left),
            get_grade(bmi, measurement.get("grade_bmi")),
        ]
        return calculate_total_grade(all_grades)

    @staticmethod
    def process_measurement_data(measurement: Dict) -> Dict:
        """측정 데이터를 처리하여 필요한 모든 값 계산"""
        height = measurement.get("height", 0) or 0
        weight = measurement.get("weight", 0) or 0
        bmi = calculate_bmi(height, weight)

        grip_left, grip_right = MeasurementService.extract_grip_data(measurement)
        grade_grip_left, grade_grip_right = MeasurementService.extract_grip_grades(measurement)

        grade_total = MeasurementService.calculate_all_grades(
            measurement, bmi, grip_left, grip_right, grade_grip_left, grade_grip_right
        )

        return {
            "height": height,
            "weight": weight,
            "bmi": bmi,
            "grip_left": grip_left,
            "grip_right": grip_right,
            "grade_grip_left": grade_grip_left,
            "grade_grip_right": grade_grip_right,
            "grade_total": grade_total,
            "grade_50m": get_grade(measurement.get("50mRun"), measurement.get("grade_50mRun")),
            "grade_shuttle": get_grade(measurement.get("shuttleRun"), measurement.get("grade_shuttleRun")),
            "grade_rolling_up": get_grade(measurement.get("rollingUp"), measurement.get("grade_rollingUp")),
            "grade_flexibility": get_grade(measurement.get("sitAndReach"), measurement.get("grade_sitAndReach")),
            "grade_long_jump": get_grade(measurement.get("longJump"), measurement.get("grade_longJump")),
            "grade_bmi": get_grade(bmi, measurement.get("grade_bmi")),
        }


measurement_service = MeasurementService()